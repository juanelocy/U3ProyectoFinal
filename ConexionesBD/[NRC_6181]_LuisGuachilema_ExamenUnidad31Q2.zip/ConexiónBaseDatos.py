from abc import ABC, abstractmethod
import pymongo
class conectarseBaseDeDatos(ABC):
    '''
    class conectarseBaseDeDatos(ABC):
        Clase abstracta para conectar a la base de datos MongoDb
    Atributos: 
    -----------------
        nombreBaseDatos: Tipo String, que contiene el nombre de la base de datos a conectar
    Métodos abstractos:
    -------------------
    def conectar(self,host,port,timeOut):
        Método abstracto para conectar a la base de datos MongoDb mediante el host, puerto y tiempo de espera 
    '''
    @abstractmethod
    def __init__(self, nombreBaseDeDatos):
        '''
        def __init__(self, nombreBaseDeDatos):
            Metodo constructor de la clase conectarseBaseDeDatos, el cual es un método abstracto y necesita el nombre de la base de 
            con la que se quiere conectar a MongoDb
        Atributos:
        -----------------
            nombreBaseDeDatos: Tipo String, que contiene el nombre de la base de datos a conectar
        '''
        nombreBaseDeDatos=nombreBaseDeDatos
    @abstractmethod
    def conectar(self, host, puerto, tiempoFuera):
        '''
        def conectar(self, host, puerto, tiempoFuera):
            Método abstracto para conectar a la base de datos MongoDb mediante el host, puerto y tiempo de espera
            el cual está vacía porque al conectar a cualquier otra base de datos se debe implementar el método 
            ya que que un diferente en cada base de datos, pero si o si existe un método para conectar a la base de datos
            y dependiendo la base dato se reecribirá el método conectar en cada clase hija.
        Parametros:
        -----------------
            host: Tipo String, que contiene el host de la base de datos a conectar
            puerto: Tipo Int, que contiene el puerto de la base de datos a conectar
            tiempoFuera: Tipo Int, que contiene el tiempo de espera de la base de datos a conectar
        '''
        pass
class MongoDb(conectarseBaseDeDatos):
    '''
    Class mongoDb(conectarseBaseDeDatos): 
        Clase que hereda de la clase conectarseBaseDeDatos y contiene el método conectar para conectar a la base de datos MongoDb
    Atributos:
    -----------------
        nombreBaseDeDatos: Tipo String, que contiene el nombre de la base de datos a conectar (MONGO)
    Métodos:
    -------------------
        def __init__(self, nombreBaseDeDatos):
            Metodo constructor de la clase mongoDb, el cual es un método abstracto y necesita el nombre de la base de datos a conectar
        def conectar(self, host, puerto, tiempoFuera):
            Método para conectar a la base de datos MongoDb mediante el host, puerto y tiempo de espera
        def eliminarColeccion(self, cleinte, nombreColeccion):
            Método para eliminar la coleccion de la base de datos MongoDb
    '''
    def __init__(self, nombreBaseDeDatos):
        '''
        def __init__(self, nombreBaseDeDatos):
            Metodo constructor de la clase MongoDb, el cual es un método abstracto y necesita el nombre de la base de datos a conectar
        Atributos:
        -----------------
            nombreBaseDeDatos: Tipo String, que contiene el nombre de la base de datos a conectar (MONGO)
        
        '''
        self.nombreBaseDeDatos=nombreBaseDeDatos
    def conectar(self, host, puerto, tiempoFuera):
        '''
        def conectar(self, host, puerto, tiempoFuera):
            Método para conectar a la base de datos MongoDb mediante el host, puerto y tiempo de espera
        Parametros:
        -----------------
            host: Tipo String, que contiene el host de la base de datos a conectar
            puerto: Tipo Int, que contiene el puerto de la base de datos a conectar
            tiempoFuera: Tipo Int, que contiene el tiempo de espera de la base de datos a conectar
        '''
        NOMBRECOLECCION="sistemaDeEmergencia911"
        MONGO_URI = "mongodb://"+host+":"+puerto+"/"
        cliente = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=tiempoFuera)
        return cliente
    def eliminarColeccion(self, cleinte, nombreColeccion):
        '''
        def eliminarColeccion(self, cleinte, nombreColeccion):
            Método para eliminar la coleccion de la base de datos MongoDb
        Parametros:
        -----------------
            cleinte: Tipo pymongo.MongoClient, que contiene el cliente de la base de datos a conectar
            nombreColeccion: Tipo String, que contiene el nombre de la coleccion a eliminar
        '''
        miBaseDatos=cleinte[self.nombreBaseDeDatos]
        miColeccion=miBaseDatos[nombreColeccion]
        print("La coleccion a eliminar es: "+nombreColeccion)
        miColeccion.drop()
    def mostrarColecciones(self, cleinte):
        '''
        def mostrarColecciones(self, cleinte):
            Método para mostrar las colecciones de la base de datos MongoDb y ne retorna una lista con las colecciones de la base de datos ingresada 
        Parametros:
        -----------------
            cleinte: Tipo pymongo.MongoClient, que contiene el cliente de la base de datos a conectar
        '''
        miBaseDatos=cleinte[self.nombreBaseDeDatos]
        return miBaseDatos.list_collection_names()
    def eliminarUsuario(self, cleinte, nombreUsuario):
        '''
        def eliminarUsuario(self, cleinte, nombreUsuario):
            Método para eliminar el usuario de la base de datos MongoDb
        Parametros:
        -----------------
            cleinte: Tipo pymongo.MongoClient, que contiene el cliente de la base de datos a conectar
            nombreUsuario: Tipo String, que contiene el nombre del usuario a eliminar
        '''
        miBaseDatos=cleinte[self.nombreBaseDeDatos]
        miUsuario=miBaseDatos[nombreUsuario]
        print("El usuario a eliminar es: "+nombreUsuario)
        miUsuario.drop()
    
    