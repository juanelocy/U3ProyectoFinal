import pymongo
from guardarMongo import *
from  ConexiónBaseDatos import *
ConectarMongoDb=MongoDb("bancoLuis")
cliente=ConectarMongoDb.conectar("localhost","27017",1000)
baseDatos = cliente["bancoLuis"]
coleccion = baseDatos["usuarios"]
def guardarUsuario(documento):
    '''
    def guardarUsuario(documento):
        Funcion pra guardar un documento en la coleccion en MongoDb y retorna un true o false
        True si se guardo correctamente, False si no se guardo, validando con try except
    Parametro:
    -----------------
        documento: Tipo diccionario, que contiene los datos del usuario a guardar en la base de datos
    '''
    try:
        '''
        try:
            Se intenta guardar el documento en la coleccion en MongoDb y se retorna un true
        except:
            Se retorna un false si no se guardo correctamente en la base de datos
        '''
        coleccion.insert_many(documento)
        return True
    except:
        return False