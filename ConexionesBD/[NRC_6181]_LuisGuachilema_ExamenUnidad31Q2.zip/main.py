from menuPrincipal import *
if __name__=="__main__":
    menuPrincipal()